var class_chromatic_aberration =
[
    [ "OnDisable", "class_chromatic_aberration.html#af6b3c956c3388888d90b2085330437fd", null ],
    [ "StartAberration", "class_chromatic_aberration.html#a91cca338845551a160cd25a7292560c3", null ],
    [ "chromeAbShader", "class_chromatic_aberration.html#ab5e76f667db172414d4e7fdd9bb5da13", null ],
    [ "duration", "class_chromatic_aberration.html#a46ec4acff342ae183ce8f74ae2463822", null ],
    [ "speedMulti", "class_chromatic_aberration.html#ab85e5f10c6efe481b8d0ca708c28e9f4", null ],
    [ "material", "class_chromatic_aberration.html#a070fe5492801915d88335235bbfc5f09", null ]
];