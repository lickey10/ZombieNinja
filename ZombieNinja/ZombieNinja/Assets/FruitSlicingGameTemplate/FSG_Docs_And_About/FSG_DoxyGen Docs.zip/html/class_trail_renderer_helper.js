var class_trail_renderer_helper =
[
    [ "mTime", "class_trail_renderer_helper.html#a632dd773ad85dfd512bb4eac39607a2e", null ],
    [ "mTrail", "class_trail_renderer_helper.html#a9640208b0e84dc5511e167702e38accf", null ]
];