var class_dojo_boundary_controller =
[
    [ "OnTriggerEnter", "class_dojo_boundary_controller.html#a3d83cfde33a72c3ba6b4cc50fb8e5831", null ],
    [ "fruitMissedX", "class_dojo_boundary_controller.html#a2484f54ede68217e9560aaebd83ee1f7", null ],
    [ "redXHeight", "class_dojo_boundary_controller.html#aeca4fed29261dce4a82810a06b4630ab", null ]
];