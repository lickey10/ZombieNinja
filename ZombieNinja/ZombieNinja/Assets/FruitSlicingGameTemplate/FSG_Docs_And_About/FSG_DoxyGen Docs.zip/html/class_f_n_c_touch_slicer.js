var class_f_n_c_touch_slicer =
[
    [ "GetSlicerDirection", "class_f_n_c_touch_slicer.html#a8d41f71fe00531831b3bd9af75e3b4bb", null ],
    [ "OnTriggerEnter", "class_f_n_c_touch_slicer.html#aaf9440acd01cbb2d97da5b318c387ac1", null ],
    [ "emulateTouchesWithMouse", "class_f_n_c_touch_slicer.html#acba1779bb23b433d6a8b3cd2a4c32cdf", null ],
    [ "maxQueueSize", "class_f_n_c_touch_slicer.html#a9bf37b9e2f8d4e5cac946558871c6f07", null ],
    [ "minimumSliceDistanceForAudio", "class_f_n_c_touch_slicer.html#a9d73b1c1cfbdff3847ce08e0b7028914", null ],
    [ "minimumTimeBetweenSwipes", "class_f_n_c_touch_slicer.html#ad0876795186b7c9fb1a7930c2a79dacf", null ],
    [ "sliceableObjects", "class_f_n_c_touch_slicer.html#abbb9447997eb8f54f7f895b703cd1052", null ],
    [ "swordSlashSounds", "class_f_n_c_touch_slicer.html#add3991af93bf34e3c1bae051c5524cd9", null ],
    [ "useColliderAndRaycast", "class_f_n_c_touch_slicer.html#ae11d4fe21fb777bdb4b8ab131b266680", null ]
];