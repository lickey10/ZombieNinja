var class_screen_fader_singleton =
[
    [ "ScreenFaderSingleton", "class_screen_fader_singleton.html#a45e4fee40c467f72a2074bf51475136d", null ],
    [ "DebugSpawn", "class_screen_fader_singleton.html#a36158526aaf53b4add76b5883c779465", null ],
    [ "DelayedFadeOut", "class_screen_fader_singleton.html#acd31bf7e42d359b3687692cdb7917ee1", null ],
    [ "FadeAndGoBack", "class_screen_fader_singleton.html#a2b3822b027837063ad9097693ca81525", null ],
    [ "FadeAndLoadLevel", "class_screen_fader_singleton.html#a0a8357475178d7341d39c2145c78d3bf", null ],
    [ "FadeAndLoadLevelFaster", "class_screen_fader_singleton.html#a76835cb2598701ed129a70b5cbaa447c", null ],
    [ "FadeAndLoadMainMenu", "class_screen_fader_singleton.html#a3ad12044d35441d5dd0786329037d8f9", null ],
    [ "FadeAndLoadPreviousLevel", "class_screen_fader_singleton.html#a32a444fa38b5801e2303b19c0ec162d0", null ],
    [ "FadeAndLoadSpecificLevel", "class_screen_fader_singleton.html#a8150903e7dc0f2fd6666441f64140847", null ],
    [ "FadeAndLoadSpecificLevelFaster", "class_screen_fader_singleton.html#a072adddb094c8c2dca15c3faa57893ba", null ],
    [ "FadeAndQuitApplication", "class_screen_fader_singleton.html#a4f4c7079c45d6ca444856307d6c913e0", null ],
    [ "FadeAndReloadLevel", "class_screen_fader_singleton.html#afb0bfe1366553fe8874743f7cbba4c7f", null ],
    [ "ZeroOutPlayerScore", "class_screen_fader_singleton.html#a224aa7cf8dd331941054dd9482c71711", null ],
    [ "fadeInDuration", "class_screen_fader_singleton.html#a932c5a89d3b71d86018b989624549c62", null ],
    [ "fadeOutDuration", "class_screen_fader_singleton.html#ab32abd26d8a0234871a216a99a9e4f87", null ],
    [ "faderPrefab", "class_screen_fader_singleton.html#a0318428965b50b92a8c2a83daf9c7001", null ],
    [ "screenFadeTexture", "class_screen_fader_singleton.html#a48a54bb8f7c91a3ef7e09cb1a424122e", null ]
];