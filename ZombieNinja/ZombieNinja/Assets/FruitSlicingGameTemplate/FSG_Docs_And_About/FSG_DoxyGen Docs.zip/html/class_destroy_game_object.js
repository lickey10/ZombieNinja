var class_destroy_game_object =
[
    [ "delay", "class_destroy_game_object.html#a09395865e95b487f3af4b2eb87e1016b", null ],
    [ "destroyChildren", "class_destroy_game_object.html#ab8c4536414bf43c0800d24a9b87e4f89", null ],
    [ "destroySound", "class_destroy_game_object.html#a047ddfa4d83caee02be8a8a9c95f3776", null ],
    [ "pushChildAmount", "class_destroy_game_object.html#a87b4309227efc18efbbccdaf2aba6235", null ]
];