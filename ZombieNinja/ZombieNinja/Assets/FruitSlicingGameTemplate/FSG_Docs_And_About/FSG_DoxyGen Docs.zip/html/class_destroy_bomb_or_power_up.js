var class_destroy_bomb_or_power_up =
[
    [ "ActivateDestructionPerObjecType", "class_destroy_bomb_or_power_up.html#af4e39c2ad04fb2ff6098f536d22ab5b7", null ],
    [ "ExplosionBlastForce", "class_destroy_bomb_or_power_up.html#afb1dec480606d84de3223cac33f98638", null ],
    [ "chroma", "class_destroy_bomb_or_power_up.html#aa70849a49ea4c5d1f2f8c734790a3faf", null ],
    [ "freezeParticleEffect", "class_destroy_bomb_or_power_up.html#a6f419b85567e2d85c043d21d463213fa", null ],
    [ "frenzyParticleEffect", "class_destroy_bomb_or_power_up.html#a50e40564da88f9a14fbfa514e3b1111c", null ],
    [ "gameOverBombGibs", "class_destroy_bomb_or_power_up.html#abfb930499bfb1705eedab357ebbaa648", null ],
    [ "gameOverBombParticleEffect", "class_destroy_bomb_or_power_up.html#a2217e02c7f2b0706844f6e7e45d07403", null ],
    [ "minusTenBombGibs", "class_destroy_bomb_or_power_up.html#abeab5e3fd121ff02c942dc69c09c0c4e", null ],
    [ "minusTenParticleEffect", "class_destroy_bomb_or_power_up.html#a900a251ceb0fb15381eb6e0c3641a57f", null ],
    [ "oType", "class_destroy_bomb_or_power_up.html#aa8267cd6f6e52820e0667b105950e035", null ],
    [ "shake", "class_destroy_bomb_or_power_up.html#ae59736d2a0085fd4ec866b56ef7f2ab2", null ],
    [ "twoTimesScoreParticleEffect", "class_destroy_bomb_or_power_up.html#afbb5885aaff564a033c09f706284278e", null ]
];