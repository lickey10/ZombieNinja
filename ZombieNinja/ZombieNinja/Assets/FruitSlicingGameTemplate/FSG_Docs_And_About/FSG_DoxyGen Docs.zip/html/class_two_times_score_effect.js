var class_two_times_score_effect =
[
    [ "StartEffect", "class_two_times_score_effect.html#ab29e50f0b32cd2855e6487b46df3f6e4", null ],
    [ "twoTimesScoreIsOn", "class_two_times_score_effect.html#ac986caceaab74b787636ddcf0a51992c", null ],
    [ "twoTimesScoreText", "class_two_times_score_effect.html#a19c627587c8b2c0f3755507e31ffcbce", null ]
];