var class_freeze_effect =
[
    [ "EndEffect", "class_freeze_effect.html#a632f1980fd1f6b7f7532a638546a0ac8", null ],
    [ "EndSnowEffect", "class_freeze_effect.html#a3d4b85d63b81b26ef9e94aeb6f21c4e1", null ],
    [ "EndTimeSlowDownEffect", "class_freeze_effect.html#a5fa76f8051a542dee9a116905d4d98bb", null ],
    [ "StartEffect", "class_freeze_effect.html#a5c4ab435b38b29eaf80e2c9459c6d665", null ],
    [ "StartSnowEffect", "class_freeze_effect.html#a790ddd81e1fc5d12efe5f227d4f1397c", null ],
    [ "StartTimeSlowdownEffect", "class_freeze_effect.html#a50907b078d9ac5050ef540ca1e177b67", null ],
    [ "borderFadeInSpeed", "class_freeze_effect.html#a8514aa08835bb875de109fbac0cbc5d3", null ],
    [ "borderFadeOutSpeed", "class_freeze_effect.html#a6fc5ba6bda51da01336e811baec3cb9f", null ],
    [ "borderFreezeDuration", "class_freeze_effect.html#a3b38bc1fdcdc5109469a2fbf2e4b01cb", null ],
    [ "freezeEffectGameObject", "class_freeze_effect.html#a9b04f5ef16d2b4b48ae9595a489d8451", null ],
    [ "freezeEffectIsOn", "class_freeze_effect.html#ab201a201c3b320e12f39c450e29f4abb", null ],
    [ "freezeScreenSprites", "class_freeze_effect.html#a628a1405230fd196403a77084baf35e3", null ],
    [ "snowParticleSystemGameObject", "class_freeze_effect.html#a461e6f5c64a94b46c2d84c74a6cc21c3", null ],
    [ "textFadeInSpeed", "class_freeze_effect.html#afc3dfe7361b9ea84fab51a76ccb99a1d", null ],
    [ "textFadeOutSpeed", "class_freeze_effect.html#abf23ee1ec44b77e535012ddc26861f49", null ],
    [ "textFreezeDuration", "class_freeze_effect.html#a3d22e19571211574fa74441331a38fd4", null ]
];