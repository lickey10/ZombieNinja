var class_u_i_dojo_selector =
[
    [ "RunChangeNext", "class_u_i_dojo_selector.html#a9da81e9789ca929f28027c2f73dc3a57", null ],
    [ "RunChangePrevious", "class_u_i_dojo_selector.html#a9393e1f8a06fb7c7bd762c325a430b62", null ]
];