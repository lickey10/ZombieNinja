var class_settings_and_pause_menu =
[
    [ "CallMenuOnly", "class_settings_and_pause_menu.html#a365b0ecb0cdabec7fa6ce0d4c23a5588", null ],
    [ "CallPauseAndMenu", "class_settings_and_pause_menu.html#ab0b0079d7d07df9b4c60db1cedc061e0", null ],
    [ "Debugging", "class_settings_and_pause_menu.html#a10ec8c0077a746c3ce18d4ee708f4bf7", null ],
    [ "Debugging", "class_settings_and_pause_menu.html#a1a69ec7348f7528121d8138bf38b3815", null ],
    [ "FaderExitApplication", "class_settings_and_pause_menu.html#ac3224aae55b07c9bda78994e06fed662", null ],
    [ "FaderLoadMainMenu", "class_settings_and_pause_menu.html#a98a249b0a08e2b1f6aab47f8016575b6", null ],
    [ "FaderReloadLevel", "class_settings_and_pause_menu.html#aa5633c5ad856b1997c0e66facddec811", null ],
    [ "MuteAudio", "class_settings_and_pause_menu.html#a79cd1681386391576be56aed42cbc030", null ],
    [ "PauseGame", "class_settings_and_pause_menu.html#a818a64deabef1427489063a93896feba", null ],
    [ "TheGameIsDoneResetting", "class_settings_and_pause_menu.html#a6cc845ed86b1674d07ac506f15073e52", null ],
    [ "TheGameIsResetting", "class_settings_and_pause_menu.html#aea082bf1c4fdfe8f5f5fb58b6a8b5ef9", null ],
    [ "ignoreGameTime", "class_settings_and_pause_menu.html#a07a5f5a8519987225f86c2f824fe4f11", null ],
    [ "moveSpeed", "class_settings_and_pause_menu.html#a8c0dccaa5602560fa797e48f9f8a3571", null ],
    [ "musicOnOffSlider", "class_settings_and_pause_menu.html#a326fb98393443e80d664093456b40ae7", null ],
    [ "pauseMenu", "class_settings_and_pause_menu.html#a2e534cad87ef4cfeb48d4006a2a35684", null ],
    [ "slideCurve", "class_settings_and_pause_menu.html#a397a9f1037aacfef5d7a830ecef63cb1", null ],
    [ "slideFromPosition", "class_settings_and_pause_menu.html#a449c3d4c8741036a660fe7824b414242", null ],
    [ "slideToPosition", "class_settings_and_pause_menu.html#ac1c72390f79bd82545fd5a3da2cb09d6", null ],
    [ "theGameIsResetting", "class_settings_and_pause_menu.html#a46073adfc6e8432401c0e2b9c334ddda", null ],
    [ "tintedColorBG", "class_settings_and_pause_menu.html#a9529cfc9d484c5903c9051c32dd540e7", null ],
    [ "useScreenSizeCalculations", "class_settings_and_pause_menu.html#abd43fb40bc13b06249e75c9269845546", null ]
];