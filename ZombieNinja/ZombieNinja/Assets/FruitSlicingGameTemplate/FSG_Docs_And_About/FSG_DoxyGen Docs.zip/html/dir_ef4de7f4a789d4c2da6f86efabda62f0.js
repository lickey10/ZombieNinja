var dir_ef4de7f4a789d4c2da6f86efabda62f0 =
[
    [ "AnimationCurveMover.cs", "_animation_curve_mover_8cs.html", [
      [ "AnimationCurveMover", "class_animation_curve_mover.html", "class_animation_curve_mover" ]
    ] ],
    [ "ChromaticAberration.cs", "_chromatic_aberration_8cs.html", [
      [ "ChromaticAberration", "class_chromatic_aberration.html", "class_chromatic_aberration" ]
    ] ],
    [ "CountdownTimer.cs", "_countdown_timer_8cs.html", [
      [ "CountdownTimer", "class_countdown_timer.html", "class_countdown_timer" ]
    ] ],
    [ "DestroyBombOrPowerUp.cs", "_destroy_bomb_or_power_up_8cs.html", "_destroy_bomb_or_power_up_8cs" ],
    [ "DestroyFruit.cs", "_destroy_fruit_8cs.html", [
      [ "DestroyFruit", "class_destroy_fruit.html", "class_destroy_fruit" ]
    ] ],
    [ "DestroyGameObject.cs", "_destroy_game_object_8cs.html", [
      [ "DestroyGameObject", "class_destroy_game_object.html", "class_destroy_game_object" ]
    ] ],
    [ "DisableGameObject.cs", "_disable_game_object_8cs.html", [
      [ "DisableGameObject", "class_disable_game_object.html", "class_disable_game_object" ]
    ] ],
    [ "DojoBoundaryController.cs", "_dojo_boundary_controller_8cs.html", [
      [ "DojoBoundaryController", "class_dojo_boundary_controller.html", "class_dojo_boundary_controller" ]
    ] ],
    [ "FaderCaller.cs", "_fader_caller_8cs.html", [
      [ "FaderCaller", "class_fader_caller.html", null ]
    ] ],
    [ "FaderReferenceSetup.cs", "_fader_reference_setup_8cs.html", [
      [ "FaderReferenceSetup", "class_fader_reference_setup.html", "class_fader_reference_setup" ]
    ] ],
    [ "FNCTouchSlicer.cs", "_f_n_c_touch_slicer_8cs.html", [
      [ "FNCTouchSlicer", "class_f_n_c_touch_slicer.html", "class_f_n_c_touch_slicer" ]
    ] ],
    [ "FreezeEffect.cs", "_freeze_effect_8cs.html", [
      [ "FreezeEffect", "class_freeze_effect.html", "class_freeze_effect" ]
    ] ],
    [ "FrenzyEffect.cs", "_frenzy_effect_8cs.html", [
      [ "FrenzyEffect", "class_frenzy_effect.html", "class_frenzy_effect" ]
    ] ],
    [ "FruitDestroyCombo.cs", "_fruit_destroy_combo_8cs.html", [
      [ "FruitDestroyCombo", "class_fruit_destroy_combo.html", "class_fruit_destroy_combo" ]
    ] ],
    [ "FruitLauncher.cs", "_fruit_launcher_8cs.html", [
      [ "FruitLauncher", "class_fruit_launcher.html", "class_fruit_launcher" ]
    ] ],
    [ "GameController.cs", "_game_controller_8cs.html", "_game_controller_8cs" ],
    [ "GameVariables.cs", "_game_variables_8cs.html", null ],
    [ "GenericUIElementFade.cs", "_generic_u_i_element_fade_8cs.html", [
      [ "GenericUIElementFade", "class_generic_u_i_element_fade.html", "class_generic_u_i_element_fade" ]
    ] ],
    [ "LauncherController.cs", "_launcher_controller_8cs.html", [
      [ "LauncherController", "class_launcher_controller.html", "class_launcher_controller" ]
    ] ],
    [ "ObjectFollow.cs", "_object_follow_8cs.html", [
      [ "ObjectFollow", "class_object_follow.html", "class_object_follow" ]
    ] ],
    [ "ObjectPoolScript.cs", "_object_pool_script_8cs.html", [
      [ "ObjectPoolScript", "class_object_pool_script.html", "class_object_pool_script" ]
    ] ],
    [ "RotateObject.cs", "_rotate_object_8cs.html", [
      [ "RotateObject", "class_rotate_object.html", "class_rotate_object" ]
    ] ],
    [ "ScreenFaderSingleton.cs", "_screen_fader_singleton_8cs.html", [
      [ "ScreenFaderSingleton", "class_screen_fader_singleton.html", "class_screen_fader_singleton" ]
    ] ],
    [ "SelectDojoBackground.cs", "_select_dojo_background_8cs.html", [
      [ "SelectDojoBackground", "class_select_dojo_background.html", "class_select_dojo_background" ]
    ] ],
    [ "SettingsAndPauseMenu.cs", "_settings_and_pause_menu_8cs.html", [
      [ "SettingsAndPauseMenu", "class_settings_and_pause_menu.html", "class_settings_and_pause_menu" ]
    ] ],
    [ "ShowCutFruitUI.cs", "_show_cut_fruit_u_i_8cs.html", [
      [ "ShowCutFruitUI", "class_show_cut_fruit_u_i.html", "class_show_cut_fruit_u_i" ]
    ] ],
    [ "SimpleCameraShake.cs", "_simple_camera_shake_8cs.html", [
      [ "SimpleCameraShake", "class_simple_camera_shake.html", "class_simple_camera_shake" ]
    ] ],
    [ "Singleton.cs", "_singleton_8cs.html", [
      [ "Singleton", "class_singleton.html", "class_singleton" ]
    ] ],
    [ "SplatterFade.cs", "_splatter_fade_8cs.html", [
      [ "SplatterFade", "class_splatter_fade.html", "class_splatter_fade" ]
    ] ],
    [ "Tags.cs", "_tags_8cs.html", null ],
    [ "TrailRendererHelper.cs", "_trail_renderer_helper_8cs.html", [
      [ "TrailRendererHelper", "class_trail_renderer_helper.html", "class_trail_renderer_helper" ]
    ] ],
    [ "TwoTimesScoreEffect.cs", "_two_times_score_effect_8cs.html", [
      [ "TwoTimesScoreEffect", "class_two_times_score_effect.html", "class_two_times_score_effect" ]
    ] ],
    [ "UIDojoSelector.cs", "_u_i_dojo_selector_8cs.html", [
      [ "UIDojoSelector", "class_u_i_dojo_selector.html", "class_u_i_dojo_selector" ]
    ] ]
];