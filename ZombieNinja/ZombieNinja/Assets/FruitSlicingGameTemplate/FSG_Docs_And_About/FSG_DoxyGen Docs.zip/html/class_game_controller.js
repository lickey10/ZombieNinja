var class_game_controller =
[
    [ "TakeFruitAndEndGame", "class_game_controller.html#a41e26aa5add3a249655ffed2f521f2dc", null ],
    [ "arcadeHighestText", "class_game_controller.html#a0338004177a9e308f0777c3e2efe24bd", null ],
    [ "arcadeText", "class_game_controller.html#a7f198bdda0d1effd08e344bb17997fcc", null ],
    [ "blueXClassicMode", "class_game_controller.html#ad6b5f79c953dd176266eabc5cf468244", null ],
    [ "classicHighestText", "class_game_controller.html#a3c7c3bf14b29298fd12dda201376d9e6", null ],
    [ "classicText", "class_game_controller.html#a275325169a4683aa583b9fd752cbdf93", null ],
    [ "gameIsRunning", "class_game_controller.html#a67341a4d883a1f963d3faa78bde03b3d", null ],
    [ "gameModes", "class_game_controller.html#a3cdcdaacf8064aee0ed3c9ca365c7984", null ],
    [ "gameOverPanel", "class_game_controller.html#a98b335505c99b20a67cf0e48bc2a1178", null ],
    [ "redXClassicMode", "class_game_controller.html#adc381d1adafa765e77d476973fd26982", null ],
    [ "relaxHighestText", "class_game_controller.html#aea81fea7db9d373afbcaa5e27a4b0692", null ],
    [ "relaxText", "class_game_controller.html#a0e8603d5af067cffa53f80320a8635e2", null ],
    [ "slicerGO", "class_game_controller.html#a03bf64be839a471d82f26e93d36c348a", null ],
    [ "waitForMenuAtEnd", "class_game_controller.html#a89d748ef9ce55cc399464319e307444a", null ]
];