var class_fader_reference_setup =
[
    [ "faderRawImage", "class_fader_reference_setup.html#aac538c9af7bd90437690bfcad16de91c", null ],
    [ "parentCanvas", "class_fader_reference_setup.html#a9a9d4f574fee40e2961a58cc4cee1957", null ]
];