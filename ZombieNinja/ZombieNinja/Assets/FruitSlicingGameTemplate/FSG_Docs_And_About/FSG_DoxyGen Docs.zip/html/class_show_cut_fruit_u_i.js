var class_show_cut_fruit_u_i =
[
    [ "arcadeModeCutFruitText", "class_show_cut_fruit_u_i.html#aa684c9a1f1ef83488b45ebe89d27fba2", null ],
    [ "classicModeCutFruitText", "class_show_cut_fruit_u_i.html#a5318574ab177798d8c805d6e45e89871", null ],
    [ "relaxModeCutFruitText", "class_show_cut_fruit_u_i.html#a27e03952261fb37b14130e5367624786", null ]
];