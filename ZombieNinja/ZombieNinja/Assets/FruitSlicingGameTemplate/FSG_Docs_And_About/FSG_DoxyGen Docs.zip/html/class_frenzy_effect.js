var class_frenzy_effect =
[
    [ "EndEffect", "class_frenzy_effect.html#a25a798209dfa46708d68969bed157b80", null ],
    [ "EndFrenzyParticleEffect", "class_frenzy_effect.html#a02a0b15f44bc472bf59059ba4811c112", null ],
    [ "StartEffect", "class_frenzy_effect.html#afa31b184ee9f55fd10d4100801911111", null ],
    [ "StartFrenzyParticleEffect", "class_frenzy_effect.html#a0db9fad8b972b28c5fbc3c3f12a07c69", null ],
    [ "changingColorSprite", "class_frenzy_effect.html#a6d4f9f66f76e79e36e41256c86562e18", null ],
    [ "frenzyEffectGameObject", "class_frenzy_effect.html#a8c8e9ab57777f6b437f5af9808db167e", null ],
    [ "frenzyEffectIsOn", "class_frenzy_effect.html#a1ecd3d54f83d4dc675a6418b409b2c74", null ],
    [ "frenzyParticleSystem", "class_frenzy_effect.html#ad2b8f43dd7e2eff1bb7a9561c102ec9c", null ],
    [ "frenzyScreenSprites", "class_frenzy_effect.html#a9e14e7354349b5bcf48f5580f21eb332", null ],
    [ "loopThruColorAmt", "class_frenzy_effect.html#aaf0d60b0f3070a6b55a00c79a03c6054", null ],
    [ "psDuration", "class_frenzy_effect.html#acc8e435160113f2be0be2eb68a85636d", null ],
    [ "randomBgColorsForFrenzyMode", "class_frenzy_effect.html#a958ca98126fbf2c4429e15ae549e3d5d", null ],
    [ "startAndEndColor", "class_frenzy_effect.html#ad2758557bfcb5682939cd8615189965d", null ],
    [ "textFadeInSpeed", "class_frenzy_effect.html#ae4fd6dc0b831ae853d6256188efd8c37", null ],
    [ "textFadeOutSpeed", "class_frenzy_effect.html#a89ac40a2553f618881876a9874d8b07f", null ],
    [ "textFreezeDuration", "class_frenzy_effect.html#a0095e8cf097a959438bc29dedf351da1", null ]
];