var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "AnimationCurveMover", "class_animation_curve_mover.html", null ],
      [ "ChromaticAberration", "class_chromatic_aberration.html", null ],
      [ "CountdownTimer", "class_countdown_timer.html", null ],
      [ "DestroyBombOrPowerUp", "class_destroy_bomb_or_power_up.html", null ],
      [ "DestroyFruit", "class_destroy_fruit.html", null ],
      [ "DestroyGameObject", "class_destroy_game_object.html", null ],
      [ "DisableGameObject", "class_disable_game_object.html", null ],
      [ "DojoBoundaryController", "class_dojo_boundary_controller.html", null ],
      [ "FaderCaller", "class_fader_caller.html", null ],
      [ "FaderReferenceSetup", "class_fader_reference_setup.html", null ],
      [ "FNCTouchSlicer", "class_f_n_c_touch_slicer.html", null ],
      [ "FreezeEffect", "class_freeze_effect.html", null ],
      [ "FrenzyEffect", "class_frenzy_effect.html", null ],
      [ "FruitDestroyCombo", "class_fruit_destroy_combo.html", null ],
      [ "FruitLauncher", "class_fruit_launcher.html", null ],
      [ "GameController", "class_game_controller.html", null ],
      [ "GenericUIElementFade", "class_generic_u_i_element_fade.html", null ],
      [ "LauncherController", "class_launcher_controller.html", null ],
      [ "ObjectFollow", "class_object_follow.html", null ],
      [ "ObjectPoolScript", "class_object_pool_script.html", null ],
      [ "RotateObject", "class_rotate_object.html", null ],
      [ "SelectDojoBackground", "class_select_dojo_background.html", null ],
      [ "SettingsAndPauseMenu", "class_settings_and_pause_menu.html", null ],
      [ "ShowCutFruitUI", "class_show_cut_fruit_u_i.html", null ],
      [ "SimpleCameraShake", "class_simple_camera_shake.html", null ],
      [ "Singleton< T >", "class_singleton.html", null ],
      [ "SplatterFade", "class_splatter_fade.html", null ],
      [ "TrailRendererHelper", "class_trail_renderer_helper.html", null ],
      [ "TwoTimesScoreEffect", "class_two_times_score_effect.html", null ],
      [ "UIDojoSelector", "class_u_i_dojo_selector.html", null ]
    ] ],
    [ "Singleton< ScreenFaderSingleton >", "class_singleton.html", [
      [ "ScreenFaderSingleton", "class_screen_fader_singleton.html", null ]
    ] ]
];