var class_disable_game_object =
[
    [ "OnDisable", "class_disable_game_object.html#a516cdc2c0657ecc6a84bdfba6ff3a5ba", null ],
    [ "delay", "class_disable_game_object.html#a96051502fcb86170696e372882275b03", null ]
];