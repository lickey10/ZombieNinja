var class_rotate_object =
[
    [ "rotation", "class_rotate_object.html#ad853ad5d1214689eda566b187a67fec9", null ],
    [ "space", "class_rotate_object.html#afde93cb27c5bfe81a02d899b7af5667e", null ]
];