var _game_controller_8cs =
[
    [ "GameController", "class_game_controller.html", "class_game_controller" ],
    [ "GameModes", "_game_controller_8cs.html#ae1530eae5079db496724a4857d911f09", [
      [ "Classic", "_game_controller_8cs.html#ae1530eae5079db496724a4857d911f09ad35b51b639528d580362ca7042de6a0e", null ],
      [ "Arcade", "_game_controller_8cs.html#ae1530eae5079db496724a4857d911f09aee1dde1e718954c9d03109f34f7cb3b6", null ],
      [ "Relax", "_game_controller_8cs.html#ae1530eae5079db496724a4857d911f09af2901a893d204f609b9d6d6b11a481b4", null ]
    ] ]
];