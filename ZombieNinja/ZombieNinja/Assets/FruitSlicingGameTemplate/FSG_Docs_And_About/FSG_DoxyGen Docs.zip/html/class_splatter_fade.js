var class_splatter_fade =
[
    [ "splatterQuadRenderer", "class_splatter_fade.html#a1822f7b1272315b3dfa11c16c1f96f11", null ],
    [ "timeBeforeFadeStarts", "class_splatter_fade.html#addcfe021e653e6b897b45378f0a74263", null ]
];