var class_object_follow =
[
    [ "ignoreGameTime", "class_object_follow.html#aad250d149fee4d80c4079d33fb4db17b", null ],
    [ "smoothing", "class_object_follow.html#afb119a85fdfb29004af8f4e7512ef213", null ],
    [ "target", "class_object_follow.html#a40bd5d7d2a9ee85af54e06295a03b432", null ]
];