var searchData=
[
  ['screenfadersingleton',['ScreenFaderSingleton',['../class_screen_fader_singleton.html#a45e4fee40c467f72a2074bf51475136d',1,'ScreenFaderSingleton']]],
  ['setcombotexttofruitposition',['SetComboTextToFruitPosition',['../class_fruit_destroy_combo.html#a485769ec8c5a7bdad6cea0733cd095c6',1,'FruitDestroyCombo']]],
  ['sortdistancetocombotextanchorlocation',['SortDistanceToComboTextAnchorLocation',['../class_fruit_destroy_combo.html#ac7ea0aede4e2c6c8179db457c398c937',1,'FruitDestroyCombo']]],
  ['start',['Start',['../class_object_pool_script.html#a9e184b8a67d720933f845531b960e54a',1,'ObjectPoolScript']]],
  ['startaberration',['StartAberration',['../class_chromatic_aberration.html#a91cca338845551a160cd25a7292560c3',1,'ChromaticAberration']]],
  ['starteffect',['StartEffect',['../class_freeze_effect.html#a5c4ab435b38b29eaf80e2c9459c6d665',1,'FreezeEffect.StartEffect()'],['../class_frenzy_effect.html#afa31b184ee9f55fd10d4100801911111',1,'FrenzyEffect.StartEffect()'],['../class_two_times_score_effect.html#ab29e50f0b32cd2855e6487b46df3f6e4',1,'TwoTimesScoreEffect.StartEffect()']]],
  ['startfrenzyparticleeffect',['StartFrenzyParticleEffect',['../class_frenzy_effect.html#a0db9fad8b972b28c5fbc3c3f12a07c69',1,'FrenzyEffect']]],
  ['startshake',['StartShake',['../class_simple_camera_shake.html#a6730920ed4a235ea6024880826b02bea',1,'SimpleCameraShake']]],
  ['startsnoweffect',['StartSnowEffect',['../class_freeze_effect.html#a790ddd81e1fc5d12efe5f227d4f1397c',1,'FreezeEffect']]],
  ['starttimer',['StartTimer',['../class_countdown_timer.html#a33b40f15d66bef318a315f9607a9a2be',1,'CountdownTimer']]],
  ['starttimeslowdowneffect',['StartTimeSlowdownEffect',['../class_freeze_effect.html#a50907b078d9ac5050ef540ca1e177b67',1,'FreezeEffect']]],
  ['stopandresettimer',['StopAndResetTimer',['../class_countdown_timer.html#abb511cfa28fbde4efe93167c729f49c6',1,'CountdownTimer']]]
];
