var searchData=
[
  ['instance',['Instance',['../class_singleton.html#a54103e8475b2a352ee759d5732307534',1,'Singleton']]]
];
