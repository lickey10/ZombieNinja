var searchData=
[
  ['classic',['Classic',['../_game_controller_8cs.html#ae1530eae5079db496724a4857d911f09ad35b51b639528d580362ca7042de6a0e',1,'GameController.cs']]]
];
