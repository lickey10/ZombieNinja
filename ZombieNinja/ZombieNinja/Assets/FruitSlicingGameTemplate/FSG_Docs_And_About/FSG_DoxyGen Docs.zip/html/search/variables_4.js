var searchData=
[
  ['emulatetoucheswithmouse',['emulateTouchesWithMouse',['../class_f_n_c_touch_slicer.html#acba1779bb23b433d6a8b3cd2a4c32cdf',1,'FNCTouchSlicer']]]
];
