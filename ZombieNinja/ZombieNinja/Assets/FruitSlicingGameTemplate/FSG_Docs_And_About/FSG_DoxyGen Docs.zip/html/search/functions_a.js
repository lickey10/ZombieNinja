var searchData=
[
  ['reducelaunchtimersandlaunchobjects',['ReduceLaunchTimersAndLaunchObjects',['../class_launcher_controller.html#a47b11e862a5462c2581224c0ece8a8e4',1,'LauncherController']]],
  ['requestfruitsalvofrombottom',['RequestFruitSalvoFromBottom',['../class_launcher_controller.html#a2c1a0e52339521038429598611d8ba1b',1,'LauncherController']]],
  ['requestfruitsalvofromside',['RequestFruitSalvoFromSide',['../class_launcher_controller.html#aa7cea144ead82569b58fd387e58247d2',1,'LauncherController']]],
  ['requestotherobjectsalvofrombottomlauncher',['RequestOtherObjectSalvoFromBottomLauncher',['../class_launcher_controller.html#ad50015232b9e24a817e28e33fa5840ea',1,'LauncherController']]],
  ['resetcombotimer',['ResetComboTimer',['../class_fruit_destroy_combo.html#a6b12238e6b5522493426cfef0cfb6347',1,'FruitDestroyCombo']]],
  ['retrievefruitfrompool',['RetrieveFruitFromPool',['../class_fruit_launcher.html#a7feaf6d5b8087164a5bf80e5616b2614',1,'FruitLauncher']]],
  ['retrieveotherfrompool',['RetrieveOtherFromPool',['../class_fruit_launcher.html#a40800b221c9bc7b0a93b65618f3321c4',1,'FruitLauncher']]],
  ['runchangenext',['RunChangeNext',['../class_u_i_dojo_selector.html#a9da81e9789ca929f28027c2f73dc3a57',1,'UIDojoSelector']]],
  ['runchangeprevious',['RunChangePrevious',['../class_u_i_dojo_selector.html#a9393e1f8a06fb7c7bd762c325a430b62',1,'UIDojoSelector']]]
];
