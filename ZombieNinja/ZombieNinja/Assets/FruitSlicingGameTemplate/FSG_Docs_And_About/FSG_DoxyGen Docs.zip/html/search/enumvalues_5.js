var searchData=
[
  ['relax',['Relax',['../_game_controller_8cs.html#ae1530eae5079db496724a4857d911f09af2901a893d204f609b9d6d6b11a481b4',1,'GameController.cs']]]
];
