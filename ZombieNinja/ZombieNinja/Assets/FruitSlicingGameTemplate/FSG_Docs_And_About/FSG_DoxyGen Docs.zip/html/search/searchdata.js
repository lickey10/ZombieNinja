var indexSectionsWithContent =
{
  0: "abcdefgilmnopqrstuwz",
  1: "acdfglorstu",
  2: "acdfglorstu",
  3: "acdefglmoprstz",
  4: "abcdefgilmnopqrstuw",
  5: "go",
  6: "acfgmrt",
  7: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties"
};

