var searchData=
[
  ['arcade',['Arcade',['../_game_controller_8cs.html#ae1530eae5079db496724a4857d911f09aee1dde1e718954c9d03109f34f7cb3b6',1,'GameController.cs']]]
];
