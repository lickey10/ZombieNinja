var searchData=
[
  ['randombgcolorsforfrenzymode',['randomBgColorsForFrenzyMode',['../class_frenzy_effect.html#a958ca98126fbf2c4429e15ae549e3d5d',1,'FrenzyEffect']]],
  ['redxclassicmode',['redXClassicMode',['../class_game_controller.html#adc381d1adafa765e77d476973fd26982',1,'GameController']]],
  ['redxheight',['redXHeight',['../class_dojo_boundary_controller.html#aeca4fed29261dce4a82810a06b4630ab',1,'DojoBoundaryController']]],
  ['relaxhighesttext',['relaxHighestText',['../class_game_controller.html#aea81fea7db9d373afbcaa5e27a4b0692',1,'GameController']]],
  ['relaxmodecutfruittext',['relaxModeCutFruitText',['../class_show_cut_fruit_u_i.html#a27e03952261fb37b14130e5367624786',1,'ShowCutFruitUI']]],
  ['relaxmodeextrafruit',['RelaxModeExtraFruit',['../class_launcher_controller.html#ad3d374ec415a882a8a47092f3ff9b54b',1,'LauncherController']]],
  ['relaxtext',['relaxText',['../class_game_controller.html#a0e8603d5af067cffa53f80320a8635e2',1,'GameController']]],
  ['resetfruitlauncheramount',['resetFruitLauncherAmount',['../class_launcher_controller.html#a53b42efcc603b6100abd81c7df5b0e1c',1,'LauncherController']]],
  ['rotation',['rotation',['../class_rotate_object.html#ad853ad5d1214689eda566b187a67fec9',1,'RotateObject']]]
];
