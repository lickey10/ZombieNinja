var searchData=
[
  ['cannonthud',['cannonThud',['../class_fruit_launcher.html#af17acffd0d8f8024c47de5f9ff669fbd',1,'FruitLauncher']]],
  ['changingcolorsprite',['changingColorSprite',['../class_frenzy_effect.html#a6d4f9f66f76e79e36e41256c86562e18',1,'FrenzyEffect']]],
  ['chroma',['chroma',['../class_destroy_bomb_or_power_up.html#aa70849a49ea4c5d1f2f8c734790a3faf',1,'DestroyBombOrPowerUp']]],
  ['chromeabshader',['chromeAbShader',['../class_chromatic_aberration.html#ab5e76f667db172414d4e7fdd9bb5da13',1,'ChromaticAberration']]],
  ['classichighesttext',['classicHighestText',['../class_game_controller.html#a3c7c3bf14b29298fd12dda201376d9e6',1,'GameController']]],
  ['classicmodecutfruittext',['classicModeCutFruitText',['../class_show_cut_fruit_u_i.html#a5318574ab177798d8c805d6e45e89871',1,'ShowCutFruitUI']]],
  ['classictext',['classicText',['../class_game_controller.html#a275325169a4683aa583b9fd752cbdf93',1,'GameController']]],
  ['comboamountoftime',['comboAmountOfTime',['../class_fruit_destroy_combo.html#aa9084f98c1f67ab50667168097ba201b',1,'FruitDestroyCombo']]],
  ['combonumberspritesfromatlas',['comboNumberSpritesFromAtlas',['../class_fruit_destroy_combo.html#a2f48cb914880633cb07c98908cd2d077',1,'FruitDestroyCombo']]],
  ['comborect',['comboRect',['../class_fruit_destroy_combo.html#aa3ceb00191c25d11d2b832f59d3bda01',1,'FruitDestroyCombo']]],
  ['comborectparent',['comboRectParent',['../class_fruit_destroy_combo.html#ad929464595926c13a5c17ece487a0f4a',1,'FruitDestroyCombo']]],
  ['combotextlocations',['comboTextLocations',['../class_fruit_destroy_combo.html#a83cff8036c43c002d1452f8177d7481c',1,'FruitDestroyCombo']]],
  ['current',['current',['../class_object_pool_script.html#a7488edfb22421885e6a627eb1f66e8bc',1,'ObjectPoolScript']]],
  ['currentslicer',['currentSlicer',['../class_f_n_c_touch_slicer.html#a4d8e4704fc6f5c9aac9ad7259b1ddcc9',1,'FNCTouchSlicer']]]
];
