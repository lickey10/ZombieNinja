var searchData=
[
  ['getpooledobject',['GetPooledObject',['../class_object_pool_script.html#a4992b8671e5348191e1c88691f168878',1,'ObjectPoolScript']]],
  ['getslicerdirection',['GetSlicerDirection',['../class_f_n_c_touch_slicer.html#a8d41f71fe00531831b3bd9af75e3b4bb',1,'FNCTouchSlicer']]]
];
