var searchData=
[
  ['launchcontrollerinstance',['LaunchControllerInstance',['../class_launcher_controller.html#a8f7ff5464e572b632bf297df9990355a',1,'LauncherController']]],
  ['loopthrucoloramt',['loopThruColorAmt',['../class_frenzy_effect.html#aaf0d60b0f3070a6b55a00c79a03c6054',1,'FrenzyEffect']]]
];
