var searchData=
[
  ['bgtouse',['bgToUse',['../class_select_dojo_background.html#a01901db5567bc02cb745b2e05aa342f5',1,'SelectDojoBackground']]],
  ['bluexclassicmode',['blueXClassicMode',['../class_game_controller.html#ad6b5f79c953dd176266eabc5cf468244',1,'GameController']]],
  ['bombandpoweruppoolscripts',['bombAndPowerUpPoolScripts',['../class_fruit_launcher.html#abe0a4c21bcfaef258b7da093638047b0',1,'FruitLauncher']]],
  ['bombsalvoamount',['BombSalvoAmount',['../class_launcher_controller.html#abaf053efa494ced9383ddccd3215d7ab',1,'LauncherController']]],
  ['borderfadeinspeed',['borderFadeInSpeed',['../class_freeze_effect.html#a8514aa08835bb875de109fbac0cbc5d3',1,'FreezeEffect']]],
  ['borderfadeoutspeed',['borderFadeOutSpeed',['../class_freeze_effect.html#a6fc5ba6bda51da01336e811baec3cb9f',1,'FreezeEffect']]],
  ['borderfreezeduration',['borderFreezeDuration',['../class_freeze_effect.html#a3b38bc1fdcdc5109469a2fbf2e4b01cb',1,'FreezeEffect']]],
  ['bottomfruitlaunchers',['bottomFruitLaunchers',['../class_launcher_controller.html#a5c1f3ac7bbbb8f5d172d9ebcf420c977',1,'LauncherController']]],
  ['bottomlaunchersalvoamount',['bottomLauncherSalvoAmount',['../class_launcher_controller.html#a747edf4ab65973512d6be5951d54b6d5',1,'LauncherController']]]
];
