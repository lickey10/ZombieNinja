var searchData=
[
  ['takefruitandendgame',['TakeFruitAndEndGame',['../class_game_controller.html#a41e26aa5add3a249655ffed2f521f2dc',1,'GameController']]],
  ['thegameisdoneresetting',['TheGameIsDoneResetting',['../class_settings_and_pause_menu.html#a6cc845ed86b1674d07ac506f15073e52',1,'SettingsAndPauseMenu']]],
  ['thegameisresetting',['TheGameIsResetting',['../class_settings_and_pause_menu.html#aea082bf1c4fdfe8f5f5fb58b6a8b5ef9',1,'SettingsAndPauseMenu']]]
];
