var class_select_dojo_background =
[
    [ "ChangeDojoBGNext", "class_select_dojo_background.html#ab89bb7f77de3f27297621c54bcb0d76f", null ],
    [ "ChangeDojoBGPrevious", "class_select_dojo_background.html#a8f199605a10d5f2da7a4a98df3c1430e", null ],
    [ "bgToUse", "class_select_dojo_background.html#a01901db5567bc02cb745b2e05aa342f5", null ]
];